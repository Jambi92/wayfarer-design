# crotch3.py CAGE COL OUT DESIGN.json : crotch patch; rungs with chain ends (main) or interior-only (sub: side faces = quad+tri)
import numpy as np, sys, json, collections
cg,colf,out,dj=sys.argv[1:5]; D=json.load(open(dj))
z=np.load(cg); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colf).tolist()
hole=D['hole']; R=D['R']; L=D['L']; rung0=D['rung0']; rung6=D['rung6']
F=[f for i,f in enumerate(F) if i not in set(hole)]
rows=[]; km=0
for rg in D['rungs']:
    ids=[]
    for p,c in zip(rg['pts'],rg['cols']):
        V.append(p); cc.append(c); ids.append(len(V)-1)
    if rg.get('sub'): rows.append((None,ids,None))
    else: rows.append((R[km],ids,L[km])); km+=1
assert km==len(R)
Fn=[]
def trans(a,b):  # a: 5 verts (rung0/6), b: full 7-vert row ; centre fan
    return [[a[0],a[1],b[1],b[0]],[a[1],a[2],b[2],b[1]],[a[2],b[4],b[3],b[2]],[a[2],a[3],b[5],b[4]],[a[3],a[4],b[6],b[5]]]
full=lambda r:[r[0]]+r[1]+[r[2]]
Fn+=trans(rung0,full(rows[0]))
last=0
for k in range(1,len(rows)):
    a,b=rows[k-1],rows[k]
    ia,ib=a[1],b[1]
    for c in range(len(ia)-1): Fn.append([ia[c],ia[c+1],ib[c+1],ib[c]])
    # sides
    Rp=[r[0] for r in rows[:k] if r[0] is not None][-1]; Lp=[r[2] for r in rows[:k] if r[2] is not None][-1]
    if b[0] is not None:
        # close the side region from the last main rung to this main rung
        sub=[r for r in rows[last+1:k]]  # sub rows between
        # R side: polygon Rp, [interior first verts of rows last..k], Rb
        firsts=[rows[j][1][0] for j in range(last,k+1)]; lasts=[rows[j][1][-1] for j in range(last,k+1)]
        # R: Rp=rows[last][0], Rb=b[0]; faces: quad [Rp, firsts[0], firsts[1], ...]
        Rb=b[0]; Lb=b[2]; Ra=rows[last][0]; La=rows[last][2]
        n=len(firsts)
        if n==2: Fn.append([Ra,firsts[0],firsts[1],Rb]); Fn.append([lasts[0],La,Lb,lasts[1]])
        else:
            # triangles from Ra to the first sub rows, final quad to Rb
            for j in range(n-2): Fn.append([Ra,firsts[j],firsts[j+1]]); Fn.append([La,lasts[j+1],lasts[j]])
            Fn.append([Ra,firsts[n-2],firsts[n-1],Rb]); Fn.append([lasts[n-2],La,Lb,lasts[n-1]])
        last=k
Fn+=[q[::-1] for q in trans(rung6,full(rows[-1]))]
for flip in (False,True):
    F2=F+([q[::-1] for q in Fn] if flip else Fn)
    de=collections.Counter((f[i],f[(i+1)%len(f)]) for f in F2 for i in range(len(f)))
    if all(n==1 for n in de.values()) and all((b,a) in de for (a,b) in de): break
else:
    bad=[e for e,n in de.items() if n>1]; print('dup',bad[:10]); raise SystemExit('orientation failed')
used=sorted(set(i for f in F2 for i in f)); remap={o:n for n,o in enumerate(used)}
V2=np.array([V[i] for i in used]); F3=[[remap[i] for i in f] for f in F2]; cc2=np.array([cc[i] for i in used])
Fa=np.full((len(F3),4),-1)
for k,f in enumerate(F3): Fa[k,:len(f)]=f
np.savez_compressed(out,V=V2,F=Fa); np.save(out.replace('.npz','_col.npy'),cc2)
json.dump(dict(design=dj,rows=[[remap[i] for i in full(r) if i is not None] for r in rows],removed=[i for i in range(len(z['V'])) if i not in remap]),open(out.replace('.npz','_crotch.json'),'w'))
print('V',len(V2),'F',len(F3),'tris',sum(1 for f in F3 if len(f)==3),'flip',flip)
