# tubecut.py IN.npz IN_col OUT.npz "base1;base2;..." down : longitudinal loop cuts on every side strip of each quad digit tube (4 -> 8 verts per ring)
import numpy as np, sys, subprocess, os, importlib.util
inp,incol,out=sys.argv[1:4]; bases=[[int(t) for t in b.split(',')] for b in sys.argv[4].split(';')]; down=np.array([float(t) for t in sys.argv[5].split(',')])
spec=importlib.util.spec_from_file_location('tubes','/home/claude/stc/rp1e/tubes.py')
cur,curc=inp,incol; k=0
chains_all=[]
DOWNS=[np.array([float(t) for t in d.split(',')]) for d in os.environ['DOWNS'].split(';')] if os.environ.get('DOWNS') else None
for bi,b in enumerate(bases):
    dn=DOWNS[bi] if DOWNS else down
    sys.argv=['tubes.py',cur]; tb=importlib.util.module_from_spec(spec); spec.loader.exec_module(tb)
    R=tb.follow(b,dn); print('tube',b,'rings',len(R))
    chains_all.append([[r[j] for r in R] for j in range(len(b))])
for ch in chains_all:
    n=len(ch)
    for j in range(n):
        A=ch[j]; B=ch[(j+1)%n]; o='/tmp/claude-0/tc_%d.npz'%k; k+=1
        os.path.exists(o) and os.remove(o)
        r=subprocess.run(['python3','loopcut.py',cur,curc,o,','.join(map(str,A)),','.join(map(str,B)),os.environ.get('FR','0.5')],capture_output=True,text=True)
        print(r.stdout.strip()[-80:],r.stderr.strip()[-150:])
        if r.returncode: continue
        cur,curc=o,o.replace('.npz','_col.npy')
import shutil; shutil.copy(cur,out); shutil.copy(curc,out.replace('.npz','_col.npy'))
