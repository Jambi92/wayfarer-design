# earhole_onY.py SIDE CAGE OUTJSON : faces of the (already applied) ear patch in a later cage, found by vertex positions
import numpy as np, sys, json
from scipy.spatial import cKDTree
side,cg,out=sys.argv[1:4]
E=json.load(open('cage_EL_earL.json' if side=='L' else 'cage_ELR_earR.json')); base=np.load('cage_EL.npz' if side=='L' else 'cage_ELR.npz')['V']
patch=set(v for r in E['rings'] for v in r)|set(v for r in E['pocket'] for v in r); loop=E['loop']
z=np.load(cg); V=z['V']; F=[list(map(int,f[f>=0])) for f in z['F']]; kd=cKDTree(V)
mp=lambda i: int(kd.query(base[i])[1])
P=set(mp(i) for i in patch); B=[mp(i) for i in loop]
reg=[k for k,f in enumerate(F) if set(f)<=P|set(B) and set(f)&P]
json.dump(dict(reg=reg,loop=B),open(out,'w')); print(side,'faces',len(reg),'loop',len(B))
