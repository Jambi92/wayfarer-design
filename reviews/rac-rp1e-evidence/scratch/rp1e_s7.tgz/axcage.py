import numpy as np, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
s=sys.argv[1]; sg=-1 if s=='R' else 1; cg=sys.argv[2]; colp=sys.argv[3]; out=sys.argv[4]
z=np.load(cg); V=z['V']; F=[f[f>=0] for f in z['F']]; cc=np.load(colp)
C=np.load('crease_%s.npy'%s)
E=set()
for f in F:
    for i in range(len(f)): E.add(tuple(sorted((f[i],f[(i+1)%len(f)]))))
E=np.array(list(E))
box=lambda P:(P[:,0]*sg>12)&(P[:,0]*sg<34)&(P[:,2]>125)&(P[:,2]<168)&(P[:,1]>-55)&(P[:,1]<-10)
mE=box(V[E[:,0]])&box(V[E[:,1]])
fig,ax=plt.subplots(1,2,figsize=(18,9))
for a,(i,j) in zip(ax,((1,2),(0,2))):
    for e in E[mE]:
        c='r' if cc[e[0]]!=cc[e[1]] else ('k' if cc[e[0]]==1 else 'b')
        a.plot(V[e,i],V[e,j],c=c,lw=0.8)
    mv=box(V)
    for k in np.where(mv)[0]: a.text(V[k,i],V[k,j],str(k),fontsize=5)
    a.scatter(C[:,i],C[:,j],s=4,c='g'); a.set_aspect('equal'); a.grid(alpha=.3)
plt.savefig(out,dpi=70,bbox_inches='tight')
