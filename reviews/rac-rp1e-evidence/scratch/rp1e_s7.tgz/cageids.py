import numpy as np, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
cg=sys.argv[1]; outp=sys.argv[2]; sg=float(sys.argv[3])
z=np.load(cg); V=z['V']; F=[f[f>=0] for f in z['F']]
m=lambda p:((p[0] if sg>0 else 4-p[0])>7)&(p[2]>184)&(p[1]<-30)&(p[1]>-62)
fig,ax=plt.subplots(1,2,figsize=(22,11))
for a,(i,j) in zip(ax,[(1,2),(1,0)]):
    for f in F:
        if all(m(V[k]) for k in f):
            q=V[np.r_[f,f[0]]]; a.plot(q[:,i],q[:,j],'b-',lw=0.6)
    for k in range(len(V)):
        if m(V[k]): a.text(V[k,i],V[k,j],str(k),fontsize=7,color="r" if (V[k,0] if sg>0 else 4-V[k,0])>14 else 'k')
    a.set_aspect('equal'); a.grid(alpha=.3)
plt.tight_layout(); plt.savefig(outp,dpi=60)
