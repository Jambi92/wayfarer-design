# jawrings.py CAGE COL OUT 'z1,z2,...' ringjsons...   move ring verts onto the source z-outline (arc-length uniform, anchored at the front centre x=2)
import numpy as np, sys, json, os
from earsl import slice_loops, resample
cg,colf,out,zs=sys.argv[1:5]; zs=[float(t) for t in zs.split(',')]; rj=sys.argv[5:]
z=np.load(cg); V=z['V'].copy(); F=z['F']
WEIGHT=os.environ.get('CW','0')
rings=[]
for f in rj:
    R=json.load(open(f))['rungs'][:-1]; rings.append([a for a,b in R]); last=[b for a,b in R]
rings.append(last)
for zz,ring in zip(zs,rings):
    if zz<=0: continue
    L=slice_loops(2,zz); P=max([P for P,c in L if c],key=lambda P:np.ptp(P[:,0])*np.ptp(P[:,1]))
    cur=V[ring]
    # orientation match in x-y
    def ar(Q): return 0.5*np.sum(Q[:,0]*np.roll(Q[:,1],-1)-np.roll(Q[:,0],-1)*Q[:,1])
    if np.sign(ar(P))!=np.sign(ar(cur)): P=P[::-1]
    i0=int(np.argmin(P[:,1]+5*abs(P[:,0]-2)))  # front centre
    N=len(ring); Q=resample(P,N,i0)
    # ring index of front centre
    j0=int(np.argmin(cur[:,1]+5*abs(cur[:,0]-2)))
    for k in range(N): V[ring[(j0+k)%N]]=Q[k]
    print('z',zz,'perimeter %.1f'%np.sum(np.linalg.norm(np.diff(np.vstack([P,P[:1]]),axis=0),axis=1)))
np.savez_compressed(out,V=V,F=F); np.save(out.replace('.npz','_col.npy'),np.load(colf))
