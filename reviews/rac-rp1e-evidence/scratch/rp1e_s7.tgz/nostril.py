# nostril.py CAGE COL OUT SPEC.json : blind canal pockets inserted into single cage faces (mouth rectangle + canal rectangles + cap)
import numpy as np, sys, json
from orient import orient_patch, check
cg,colf,out,sj=sys.argv[1:5]; SP=json.load(open(sj))
z=np.load(cg); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colf).tolist()
rm=set(); Fn=[]
for p in SP:
    f=F[p['face']]; rm.add(p['face']); corners=f
    prev=corners
    for ring in p['rings']:   # each ring: 4 points matching the corner order
        ids=[]
        for q in ring: V.append(q); cc.append(p.get('col',2)); ids.append(len(V)-1)
        for i in range(4): Fn.append([prev[i],prev[(i+1)%4],ids[(i+1)%4],ids[i]])
        prev=ids
    Fn.append(prev[::-1])
F=[f for k,f in enumerate(F) if k not in rm]
Fn=orient_patch(F,Fn); F2=F+Fn; d,b=check(F2); assert d==0 and b==0,(d,b)
Fa=np.full((len(F2),4),-1)
for k,f in enumerate(F2): Fa[k,:len(f)]=f
np.savez_compressed(out,V=np.array(V),F=Fa); np.save(out.replace('.npz','_col.npy'),np.array(cc)); print('V',len(V),'F',len(F2))
