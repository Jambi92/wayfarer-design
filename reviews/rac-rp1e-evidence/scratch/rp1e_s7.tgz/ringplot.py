import numpy as np, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
sys.argv=[sys.argv[0]]+sys.argv[1:]
exec(open('ring11.py').read().split("if __name__=='__main__':")[0])
s=sys.argv[1]; cc=np.load(sys.argv[2]); out=sys.argv[3]
rings=arm_rings(s); J=rings[-1]
Cr=np.load('crease_%s.npy'%s)[:,:3]
fig,ax=plt.subplots(1,2,figsize=(18,9))
for a,(i,j) in zip(ax,((1,2),(0,2))):
    a.scatter(Cr[:,i],Cr[:,j],s=5,c='g')
    for k,r in enumerate(rings[-5:]):
        r=list(r)+[r[0]]; a.plot(V[r,i],V[r,j],'-o',ms=3,label='ring %d'%(len(rings)-5+k+1))
    T1=[n for v in J for n in adj[v] if n not in set(J)|set(rings[-2])]
    for v in J:
        for n in adj[v]:
            if n in T1: a.plot(V[[v,n],i],V[[v,n],j],'k-',lw=0.6)
    for n in set(T1):
        a.text(V[n,i],V[n,j],str(n),fontsize=7); 
    for v in J: a.text(V[v,i],V[v,j],str(v),fontsize=7,color='r')
    a.set_aspect('equal'); a.grid(alpha=.3); a.legend(fontsize=7)
ax[0].set_xlabel('y'); ax[1].set_xlabel('x')
plt.savefig(out,dpi=70,bbox_inches='tight')
