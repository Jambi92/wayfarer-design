import json, numpy as np, sys
sys.path.insert(0, '.'); from uigen import plan
k = int(sys.argv[1]); dz = float(sys.argv[2])
p = json.load(open('feet_plan.json'))
cur = np.vstack([np.array(p[s]['rings'][k - 1]) for s in 'LR']); cur[:, 2] += dz
tgt = np.vstack([np.array(p[s]['rings'][k]) for s in 'LR'])
B = plan(cur, tgt, (598.25, -91.85, 10.6), per=5)
json.dump(B, open('ui_ring%d.json' % k, 'w'))
for j, b in enumerate(B): print(j, [(v['i'], round(v['clr'])) for v in b])
