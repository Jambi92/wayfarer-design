import numpy as np
from earsl import slice_loops
def hooks(y, W=1.0, win=(-9,11,96,108), rmax=8, cx=1.3):
    """returns dict with C and per side (tip, mouth_out, mouth_in, outer_branch, inner_branch)"""
    best=None
    for P,c in slice_loops(1,y):
        m=(P[:,0]>win[0])&(P[:,0]<win[1])&(P[:,2]>win[2])&(P[:,2]<win[3])
        if m.sum()>best[0] if best else m.sum()>0: best=(m.sum(),P,c)
    P=best[1]; closed=best[2]
    cm=(abs(P[:,0]-cx)<1.2)&(P[:,2]<103.5); ic=np.where(cm)[0][np.argmax(P[cm][:,2])]; C=P[ic]
    n=len(P); res={'C':C}
    for sg,nm in ((-1,'R'),(1,'L')):
        # walk from C along the curve in the direction going to this side
        for d in (1,-1):
            j=(ic+d*5)%n
            if sg*(P[j,0]-C[0])>0: dirn=d; break
        idx=[(ic+dirn*k)%n for k in range(1,n//2)]
        Q=P[idx]
        # tip = farthest from C (x-z) within rmax, over the first part of the walk while z>=C.z-1.5
        dd=np.linalg.norm(Q[:,[0,2]]-C[[0,2]],axis=1); ok=(dd<rmax)
        # stop the walk when it goes below the roof by >3 (down the wall)
        stop=np.argmax(Q[:,2]<C[2]-3) if (Q[:,2]<C[2]-3).any() else len(Q)
        it=int(np.argmax(np.where(ok[:stop],dd[:stop],-1)))
        inner=Q[:it+1][::-1]   # from tip back to C
        outer=Q[it:]           # from tip outward/down the wall
        # mouth: walk outer branch from tip until distance to inner branch > W
        from scipy.spatial import cKDTree
        T=cKDTree(inner[:,[0,2]]); dist,_=T.query(outer[:,[0,2]])
        k=np.argmax(dist>W) if (dist>W).any() else len(outer)-1
        mo=outer[k]; _,ii=T.query(mo[[0,2]]); mi=inner[ii]
        res[nm]=dict(tip=Q[it],mo=mo,mi=mi,width=float(dist[:k].mean()) if k>0 else 0,depth=float(np.linalg.norm(Q[it,[0,2]]-mo[[0,2]])))
    return res
if __name__=='__main__':
    for y in (-55.5,-54,-53,-52,-51,-50,-49,-48,-47,-46,-45,-44):
        r=hooks(y); print(y,'C',r['C'][[0,2]].round(1),' '.join('%s tip %s mo %s mi %s w %.2f d %.1f'%(s,r[s]['tip'][[0,2]].round(1),r[s]['mo'][[0,2]].round(1),r[s]['mi'][[0,2]].round(1),r[s]['width'],r[s]['depth']) for s in 'RL'))
