import numpy as np, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
s=sys.argv[1]; z=np.load('earchains_%s.npz'%s); fl=z['floor']; A=z['A']; u=z['u']; v=z['v']; ths=z['ths']; N=len(ths)
fig,axs=plt.subplots(2,8,figsize=(40,11))
for i,a in enumerate(axs.ravel()):
    C=z['C%d'%i]; L=z['L%d'%i]; e1=np.cos(ths[i])*u+np.sin(ths[i])*v; X=C-fl; r=X@e1; h=X@A
    a.plot(r,h,'k',lw=1)
    for sv in range(0,int(L[-1])+1,2):
        k=np.searchsorted(L,sv); 
        if k<len(L): a.plot(r[k],h[k],'b.',ms=4); a.text(r[k],h[k],str(sv),fontsize=6)
    ir=np.argmax(h); a.plot(r[ir],h[ir],'ro')
    a.set_aspect('equal'); a.grid(alpha=.3); a.set_title('%d: th %d'%(i,np.degrees(ths[i])))
plt.savefig('earchains_%s.png'%s,dpi=45,bbox_inches='tight')
