# tubes.py cage.npz "a,b,c,d" down(x,y,z) : follow a quad tube from a 4-vert base ring (cyclic order) by face adjacency
import numpy as np, sys
z=np.load(sys.argv[1]); V=z['V']; F=[[int(x) for x in f if x>=0] for f in z['F']]
from collections import defaultdict
ef=defaultdict(list)
for k,f in enumerate(F):
    for i in range(len(f)): ef[frozenset((f[i],f[(i+1)%len(f)]))].append(k)
def step(ring,prev,down):
    n=len(ring); cands=[]
    for i in range(n):
        a,b=ring[i],ring[(i+1)%n]; cs=[]
        for k in ef[frozenset((a,b))]:
            f=F[k]
            if len(f)!=4: continue
            o=[v for v in f if v not in (a,b)]
            if any(v in prev for v in o) or any(v in ring for v in o): continue
            m=4; ia=f.index(a); na=f[(ia+1)%m] if f[(ia+1)%m]!=b else f[(ia-1)%m]
            ib=f.index(b); nb_=f[(ib+1)%m] if f[(ib+1)%m]!=a else f[(ib-1)%m]
            cs.append((na,nb_,np.dot(V[o].mean(0)-0.5*(V[a]+V[b]),down)))
        if not cs: return None
        cands.append(cs)
    import itertools
    best=None
    for combo in itertools.product(*cands):
        nxt=[None]*n; ok=True
        for i,(na,nb_,sc) in enumerate(combo):
            for v,w in ((i,na),((i+1)%n,nb_)):
                if nxt[v] is None: nxt[v]=w
                elif nxt[v]!=w: ok=False
        if ok and len(set(nxt))==n:
            sc=sum(c[2] for c in combo)
            if best is None or sc>best[0]: best=(sc,nxt)
    return None if best is None else best[1]
def follow(base,down,maxn=14):
    R=[list(base)]; prev=[]
    while len(R)<maxn:
        nx=step(R[-1],prev,down)
        if nx is None or len(set(nx))<4: break
        prev=R[-1]; R.append(nx); down=V[nx].mean(0)-V[prev].mean(0)
    return R
if __name__=='__main__':
    base=[int(t) for t in sys.argv[2].split(',')]; d=np.array([float(t) for t in sys.argv[3].split(',')])
    for r in follow(base,d): print(r,V[r].mean(0).round(1).tolist())
