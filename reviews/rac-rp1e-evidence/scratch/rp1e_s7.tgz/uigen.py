"""Generate Blender-UI click+type batches to move visible vertices (top ortho view) from current to target positions.
cal = (a, b, s): screen_x = a + s*x_cm, screen_y = b - s*y_cm. Greedy order by screen clearance.
Usage (module): plan(cur_cm Nx3, tgt_cm Nx3, cal, minsep=14, per=5) -> list of batches"""
import numpy as np, json, sys
def keys(v):
    return [{'action': 'key', 'text': {'-': 'minus', '.': 'period'}.get(c, c)} for c in '%.4f' % v]
def plan(cur, tgt, cal, minsep=14, per=5, field=(1110, 92)):
    a, b, s = cal; cur = np.array(cur, float).copy(); tgt = np.array(tgt, float)
    scr = lambda P: np.c_[a + s * P[:, 0], b - s * P[:, 1]]
    todo = list(range(len(cur))); order = []
    while todo:
        S = scr(cur); best = None
        for i in todo:
            d = np.linalg.norm(S - S[i], axis=1); d[i] = 1e9
            # also clearance at target from others
            if best is None or d.min() > best[1]: best = (i, d.min())
        i, clr = best
        order.append((i, clr, S[i].copy())); cur[i] = tgt[i]; todo.remove(i)
    batches = []; cur_b = []
    for n, (i, clr, p) in enumerate(order):
        acts = [{'action': 'left_click', 'coordinate': [int(round(p[0])), int(round(p[1]))], 'action_summary': 'Selects vertex'},
                {'action': 'double_click', 'coordinate': list(field), 'action_summary': 'Edits vertex X'}, {'action': 'wait', 'duration': 0.3}]
        for k in range(3):
            acts += [{'action': 'key', 'text': 'ctrl+a'}] + keys(tgt[i][k] / 100) + [{'action': 'key', 'text': 'Tab' if k < 2 else 'Return'}]
        cur_b.append(dict(i=i, clr=float(clr), acts=acts))
        if len(cur_b) == per: batches.append(cur_b); cur_b = []
    if cur_b: batches.append(cur_b)
    return batches
