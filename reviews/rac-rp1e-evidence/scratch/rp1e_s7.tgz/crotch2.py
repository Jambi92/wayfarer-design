# crotch2.py CAGE COL OUT DESIGN.json : 6-column crotch/pouch patch with centre fan quads at the front/back rungs
import numpy as np, sys, json, collections
cg,colf,out,dj=sys.argv[1:5]; D=json.load(open(dj))
z=np.load(cg); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colf).tolist()
hole=D['hole']; R=D['R']; L=D['L']; rung0=D['rung0']; rung6=D['rung6']
F=[f for i,f in enumerate(F) if i not in set(hole)]
rows=[]
for k,rg in enumerate(D['rungs']):
    ids=[R[k]]
    for p,c in zip(rg['pts'],rg['cols']):
        V.append([p[0],rg['y'],p[1]] if len(p)==2 else p); cc.append(c); ids.append(len(V)-1)
    ids.append(L[k]); rows.append(ids)
Fn=[]
def trans(a,b):  # a: 5 verts, b: 7 verts ; centre fan
    return [[a[0],a[1],b[1],b[0]],[a[1],a[2],b[2],b[1]],[a[2],b[4],b[3],b[2]],[a[2],a[3],b[5],b[4]],[a[3],a[4],b[6],b[5]]]
Fn+=trans(rung0,rows[0])
for k in range(len(rows)-1):
    a,b=rows[k],rows[k+1]
    for c in range(len(a)-1): Fn.append([a[c],a[c+1],b[c+1],b[c]])
Fn+=[q[::-1] for q in trans(rung6,rows[-1])]
for flip in (False,True):
    F2=F+([q[::-1] for q in Fn] if flip else Fn)
    de=collections.Counter((f[i],f[(i+1)%len(f)]) for f in F2 for i in range(len(f)))
    if all(n==1 for n in de.values()) and all((b,a) in de for (a,b) in de): break
else: raise SystemExit('orientation failed')
used=sorted(set(i for f in F2 for i in f)); remap={o:n for n,o in enumerate(used)}
V2=np.array([V[i] for i in used]); F3=[[remap[i] for i in f] for f in F2]; cc2=np.array([cc[i] for i in used])
Fa=np.full((len(F3),4),-1)
for k,f in enumerate(F3): Fa[k,:len(f)]=f
np.savez_compressed(out,V=V2,F=Fa); np.save(out.replace('.npz','_col.npy'),cc2)
json.dump(dict(design=dj,rows=[[remap[i] for i in r] for r in rows],removed=[i for i in range(len(z['V'])) if i not in remap]),open(out.replace('.npz','_crotch.json'),'w'))
print('V',len(V2),'F',len(F3),'flip',flip)
