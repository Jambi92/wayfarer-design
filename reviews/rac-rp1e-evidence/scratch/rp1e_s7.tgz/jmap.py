import numpy as np, sys
sys.argv=[sys.argv[0]]+sys.argv[1:]
exec(open('ring11.py').read().split("if __name__=='__main__':")[0])
from scipy.spatial import cKDTree
s=sys.argv[1]; rings=arm_rings(s); J=rings[-2]; Q=np.load('ccurve_%s.npy'%s); T=cKDTree(Q)
d,k=T.query(V[J])
for v,dd,kk in zip(J,d,k): print(v,V[v].round(1),'-> curve t=%d (%.1f cm) d=%.2f'%(kk,kk*0.25,dd), Q[kk].round(1))
print('ring 10 (rings[-3]):',[ (v,V[v].round(1).tolist()) for v in rings[-3]])
