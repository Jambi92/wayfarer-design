# compact printer: per vertex "click x,y -> X Y Z (m)"
import json, sys
B = json.load(open(sys.argv[1]))
for k in range(len(B)):
    print('batch', k)
    for v in B[k]:
        a = v['acts']; c = a[0]['coordinate']
        vals = []; cur = ''
        for x in a[3:]:
            t = x['text']
            if t in ('Tab', 'Return'): vals.append(cur); cur = ''
            elif t == 'ctrl+a': pass
            else: cur += {'minus': '-', 'period': '.'}.get(t, t)
        print('  ', v['i'], c, vals, round(v['clr']))
