"""targets2.py COLOURS.npy OUTPREFIX M ratio FACE_D FACE_DOT : like targets.py, plus a facing-wall exclusion:
a margin candidate v is dropped when its nearest core vertex u lies within FACE_D (cm) and n_u.n_v < FACE_DOT (opposite walls of a slit)."""
import numpy as np, sys
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree
col=np.load(sys.argv[1]); pre=sys.argv[2]; M=float(sys.argv[3]); ratio=float(sys.argv[4]); FD=float(sys.argv[5]); FDOT=float(sys.argv[6])
w=np.load('/home/claude/stc/rp1/weld.npz'); V=w['V'].astype(float); F=w['F'].astype(np.int64)
fn=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]); vn=np.zeros_like(V)
for k in range(3): np.add.at(vn,F[:,k],fn)
vn/=np.linalg.norm(vn,axis=1,keepdims=True)+1e-12
E=np.unique(np.sort(np.concatenate([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),1),axis=0)
wt=np.linalg.norm(V[E[:,0]]-V[E[:,1]],axis=1)
G=coo_matrix((wt,(E[:,0],E[:,1])),shape=(len(V),len(V))).tocsr()
cols=[int(c) for c in sys.argv[7].split(',')] if len(sys.argv)>7 else np.unique(col)
for c in cols:
    core=np.where(col==c)[0]; a,b=E[:,0],E[:,1]
    bd=np.unique(np.concatenate([a[(col[a]==c)&(col[b]!=c)],b[(col[b]==c)&(col[a]!=c)]]))
    ext=np.zeros(len(V),bool); ext[core]=True
    if len(bd):
        D=dijkstra(G,directed=False,indices=bd,min_only=True,limit=M)
        cand=np.where(np.isfinite(D)&(col!=c))[0]
        de,iu=cKDTree(V[core]).query(V[cand])
        ok=de>ratio*D[cand]
        facing=(de<FD)&((vn[core[iu]]*vn[cand]).sum(1)<FDOT)
        ok&=~facing
        ext[cand[ok]]=True
        print('colour',c,'margin',int(ok.sum()),'dropped facing',int((facing&(de>ratio*D[cand])).sum()))
    Fc=F[ext[F].all(1)]; used=np.unique(Fc); mp=-np.ones(len(V),int); mp[used]=np.arange(len(used))
    np.savez_compressed('%s_c%d.npz'%(pre,c),V=V[used],F=mp[Fc])
