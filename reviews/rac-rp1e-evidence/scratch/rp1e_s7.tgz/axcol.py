"""Geometric arm/trunk ownership at the axillae: near the concave crease, re-assign colours 1/2 by geodesic flood from
weight-coloured seeds (> SEED cm from the crease) over the source edge graph with crease edges removed.
Usage: python3 axcol.py COL_IN.npy COL_OUT.npy"""
import numpy as np, sys, collections
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from scipy.spatial import cKDTree
w=np.load('/home/claude/stc/rp1/weld.npz'); V=w['V'].astype(float); F=w['F'].astype(np.int64)
col=np.load(sys.argv[1]).copy(); SEED=float(sys.argv[3]) if len(sys.argv)>3 else 3.0
E=np.unique(np.sort(np.concatenate([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]),1),axis=0)
for s in 'RL':
    C=np.load('crease_%s.npy'%s)[:,:3]; T=cKDTree(C)
    dv,_=T.query(V); near=dv<SEED+2
    reg=np.where(near&((col==1)|(col==2)))[0]
    # crease edges: both endpoints within 0.25 cm of a crease midpoint AND edge itself sharp: approximate by vertex distance
    ok=near[E[:,0]]&near[E[:,1]]
    cvx=np.zeros(len(V),bool); cvx[np.load('creasev_%s.npy'%s)]=True
    Er=E[ok]; cut=cvx[Er[:,0]]|cvx[Er[:,1]]   # vertices lying on the crease are not traversed
    Er=Er[~cut]
    wt=np.linalg.norm(V[Er[:,0]]-V[Er[:,1]],axis=1)
    G=coo_matrix((wt,(Er[:,0],Er[:,1])),shape=(len(V),len(V))).tocsr()
    seeds={c:np.where(near&(dv>SEED)&(col==c))[0] for c in (1,2)}
    D={c:dijkstra(G,directed=False,indices=seeds[c],min_only=True) for c in (1,2)}
    tgt=np.where(near&(dv<=SEED)&((col==1)|(col==2)))[0]
    new=np.where(D[1][tgt]<=D[2][tgt],1,2); inf=~np.isfinite(np.minimum(D[1][tgt],D[2][tgt]))
    ch=(new!=col[tgt])&~inf
    print(s,'region',len(tgt),'changed',ch.sum(),'unreached',inf.sum())
    col[tgt[~inf]]=new[~inf]
    # crease vertices themselves: keep (either colour fine) 
np.save(sys.argv[2],col); print(np.bincount(col))
