# crotchmove.py IN.npz OUT.npz "lo,hi;..." heel [maxmove] : move the vertex between lo and hi (split crotch edge) to the slit floor tip at its height
import numpy as np, sys, os
from earsl import slice_loops
z=np.load(sys.argv[1]); V=z['V'].copy(); F=[[int(x) for x in f if x>=0] for f in z['F']]
cl=[list(map(int,c.split(','))) for c in sys.argv[3].split(';')]; heel=np.array([float(t) for t in sys.argv[4].split(',')]); mx=float(sys.argv[5]) if len(sys.argv)>5 else 1.5
from collections import defaultdict
nb=defaultdict(set)
for f in F:
    for i in range(len(f)): nb[f[i]].add(f[(i+1)%len(f)]); nb[f[(i+1)%len(f)]].add(f[i])
def tip(p,back,R=2.0):
    best=None
    for P,c in slice_loops(2,float(p[2])):
        d=np.linalg.norm(P[:,:2]-p[:2],axis=1); m=d<R
        if not m.any(): continue
        sc=np.where(m,(P[:,:2]-p[:2])@back[:2],-1e9); i=int(np.argmax(sc))
        if best is None or sc[i]>best[0]: best=(sc[i],P[i])
    return None if best is None else best[1]
for lo,hi in cl:
    ms=[v for v in nb[lo]&nb[hi] if v>=int(os.environ.get("MINNEW","0"))]
    ms=[v for v in ms if min(V[lo,2],V[hi,2])<V[v,2]<max(V[lo,2],V[hi,2])]
    c=0.5*(V[lo]+V[hi]); back=heel-c; back[2]=0; back/=np.linalg.norm(back)
    for m in ms:
        t=tip(V[m],back)
        if t is not None and np.linalg.norm(t-V[m])<mx: print(lo,hi,'m',m,V[m].round(2).tolist(),'->',t.round(2).tolist()); V[m]=V[m]+float(os.environ.get("MF","1.0"))*(t-V[m])
        else: print(lo,hi,'m',m,'no move',None if t is None else round(float(np.linalg.norm(t-V[m])),2))
np.savez_compressed(sys.argv[2],V=V,F=z['F'])
