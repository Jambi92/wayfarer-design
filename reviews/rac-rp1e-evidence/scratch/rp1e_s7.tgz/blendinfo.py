import bpy, sys, numpy as np
a=sys.argv[sys.argv.index('--')+1:]
bpy.ops.wm.open_mainfile(filepath=a[0])
for o in bpy.data.objects:
    print(o.name,o.type,len(o.data.vertices) if o.type=='MESH' else '', [m.type for m in o.modifiers], [g.name for g in getattr(o,'vertex_groups',[])][:20], tuple(round(x,4) for x in o.matrix_world.translation), o.hide_get() if hasattr(o,'hide_get') else '')
o=bpy.data.objects['Cylinder']; V=np.array([v.co[:] for v in o.data.vertices])*100
F=np.full((len(o.data.polygons),4),-1)
for i,p in enumerate(o.data.polygons): F[i,:len(p.vertices)]=p.vertices[:]
np.savez_compressed(a[1],V=V,F=F); print('cage',V.shape,F.shape)
