import numpy as np, collections, sys, json
s=sys.argv[1]; X0=float(sys.argv[2]); Z0=float(sys.argv[3]); cg=sys.argv[4] if len(sys.argv)>4 else 'cage_g5b.npz'
z=np.load(cg); V=z['V']; F=[list(f[f>=0]) for f in z['F']]; sg=1 if s=='L' else -1
fc=np.array([V[f].mean(0) for f in F])
reg=set(k for k in range(len(F)) if sg*fc[k][0]>X0 and fc[k][2]>Z0 and -62<fc[k][1]<-30 and fc[k][2]<206)
ed=collections.Counter()
for k in reg:
    f=F[k]
    for i in range(len(f)): ed[(f[i],f[(i+1)%len(f)])]+=1
bnd={a:b for (a,b) in ed if (b,a) not in ed}; seen=set(); L=[]
for a in list(bnd):
    if a in seen: continue
    l=[a]; seen.add(a)
    while bnd.get(l[-1],a)!=a and len(l)<500: l.append(bnd[l[-1]]); seen.add(l[-1])
    L.append(l)
print(s,X0,Z0,'faces',len(reg),'loops',[len(l) for l in L])
lp=max(L,key=len)
for i in lp: print(i,V[i].round(1))
json.dump(dict(reg=sorted(int(k) for k in reg),loop=[int(x) for x in lp]),open('earhole3_%s.json'%s,'w'))
