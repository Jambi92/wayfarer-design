import json, sys
B = json.load(open(sys.argv[1])); k = int(sys.argv[2])
acts = [a for v in B[k] for a in v['acts']] + [{'action': 'wait', 'duration': 0.4}, {'action': 'zoom', 'region': [1040, 56, 1180, 120], 'scale': 0.4}]
print(json.dumps(acts, separators=(',', ':')))
print('targets', [(v['i'], v['clr']) for v in B[k]], file=sys.stderr)
