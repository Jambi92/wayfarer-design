"""Ear sub-cage v3 (crescent rings). python3 eardesign3.py SIDE CAGE COL HOLEJSON OUT XS NT
B = hole loop (kept cage verts). Ear rings = source cross-section loops at |x| in XS (outer loop), resampled to len(B) by arc length.
NT transition rings between B and the first ear ring: lerp then snapped to nearest source point. Tip cap: zip."""
import numpy as np, sys, json
from scipy.spatial import cKDTree
from earsl import slice_loops, resample, S
s,cin,colin,hj,out,xs,NT=sys.argv[1:8]; xs=[float(x) for x in xs.split(',')]; NT=int(NT); sg=1 if s=='L' else -1
z=np.load(cin); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colin).tolist()
H=json.load(open(hj)); hole=set(H['reg']); loop=list(H['loop']); NB=len(loop); B=np.array([V[i] for i in loop])
kd=cKDTree(S); import os; SN=float(os.environ.get("SNAP","1"))
def area_yz(P): y,zz=P[:,1],P[:,2]; return 0.5*np.sum(y*np.roll(zz,-1)-np.roll(y,-1)*zz)
rings=[]
for x in xs:
    L=slice_loops(0,sg*x,lambda P:(P[:,2]>183)&(P[:,1]<-30)&(P[:,1]>-62))
    P=max([P for P,c in L if c],key=len)
    if np.sign(area_yz(P))!=np.sign(area_yz(B)): P=P[::-1]
    i0=int(np.argmin(P[:,1])); rings.append(resample(P,NB,i0))
# align ring 0 to B by cyclic shift (min sum dist in yz), then each next ring to previous
def align(R,ref):
    best=min(range(NB),key=lambda sh:np.linalg.norm(np.roll(R,-sh,axis=0)[:,1:]-ref[:,1:],axis=1).sum()); return np.roll(R,-best,axis=0)
rings[0]=align(rings[0],B)
for k in range(1,len(rings)): rings[k]=align(rings[k],rings[k-1])
T=[]
for t in range(1,NT+1):
    a=t/(NT+1); M=(1-a)*B+a*rings[0]; d,ii=kd.query(M); T.append(M+SN*(S[ii]-M))
allr=T+rings
col0=int(np.bincount([cc[i] for i in loop]).argmax())
F=[f for k,f in enumerate(F) if k not in hole]
# drop verts used only by hole faces? keep indices stable: mark orphan verts, remove later
prev=loop; ids=[]
for R in allr:
    cur=[]
    for p in R: V.append(np.asarray(p).tolist()); cc.append(col0); cur.append(len(V)-1)
    for i in range(NB): F.append([prev[i],prev[(i+1)%NB],cur[(i+1)%NB],cur[i]])
    prev=cur; ids.append(cur)
p=prev; a_,b_=0,NB-1
while b_-a_>=3: F.append([p[a_],p[a_+1],p[b_-1],p[b_]]); a_+=1; b_-=1
if b_-a_==2: F.append([p[a_],p[a_+1],p[a_+2]])
# remove orphan verts
used=sorted(set(i for f in F for i in f)); remap={o:n for n,o in enumerate(used)}
V2=np.array([V[i] for i in used]); F2=[[remap[i] for i in f] for f in F]; cc2=np.array([cc[i] for i in used])
Fa=np.full((len(F2),4),-1)
for k,f in enumerate(F2): Fa[k,:len(f)]=f
np.savez_compressed(out,V=V2,F=Fa); np.save(out.replace('.npz','_col.npy'),cc2)
json.dump(dict(side=s,hole=sorted(hole),loop=[remap[i] for i in loop],loop_orig=loop,rings=[[remap[i] for i in r] for r in ids],xs=xs,NT=NT,
   removed=[i for i in range(len(z['V'])) if i not in remap]),open(out.replace('.npz','_ear%s.json'%s),'w'))
print(s,'NB',NB,'rings',len(allr),'V',len(V2),'F',len(F2),'removed',len(z['V'])-len([i for i in used if i<len(z['V'])]))
