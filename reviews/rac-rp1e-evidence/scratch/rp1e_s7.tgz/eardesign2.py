"""Ear sub-cage v2. Usage: python3 eardesign2.py SIDE CAGE_IN CAGECOL_IN HOLE_JSON OUT RS
B = hole boundary loop (existing cage verts); S = base loop on the source: for dense theta, first chain point (after the rim)
with |p - floor| >= RS; S resampled to len(B) points by arc length, aligned to B (start = nearest, same orientation);
inner rings at theta(S_i): floor .06, d1 .25, d2 .5, d3 .75 (of rim arc), rim, b1, b2 (1/3, 2/3 rim->S_i) ; strip B->S; cap."""
import numpy as np, sys, json, collections
sys.argv=[sys.argv[0]]+sys.argv[1:]
s,cin,colin,hj,out,RS=sys.argv[1:7]; RS=float(RS)
exec(open('earchains.py').read().split("out={}")[0].replace("s=sys.argv[1]; N=int(sys.argv[2]) if len(sys.argv)>2 else 16","N=0"))
z=np.load(cin); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colin).tolist()
H=json.load(open(hj)); hole=set(H['reg']); loop=H['loop']; NB=len(loop); B=np.array([V[i] for i in loop])
def info(t):
    C,Nn,e1=chain(t); L=np.r_[0,np.cumsum(np.linalg.norm(np.diff(C,axis=0),axis=1))]; h=(C-floor)@A
    # rim = max h within the first 60 % ... use global max h before the chain leaves RS
    dist=np.linalg.norm(C-floor,axis=1); ex=np.where(dist>=RS)[0]
    iex=ex[0] if len(ex) else len(C)-1
    ir=int(np.argmax(h[:iex+1])); 
    ex2=[k for k in ex if k>ir]; iS=ex2[0] if ex2 else len(C)-1
    return C,Nn,L,ir,iS
dense=np.linspace(0,2*np.pi,96,endpoint=False); Sd=[]
for t in dense:
    C,Nn,L,ir,iS=info(t); Sd.append(C[iS])
Sd=np.array(Sd)
# orientation: B and Sd angles about A
ang=lambda P:np.unwrap(np.arctan2((P-floor)@v,(P-floor)@u))
aB=ang(B); orientB=np.sign(aB[-1]-aB[0])
if orientB<0: Sd=Sd[::-1]; dense=dense[::-1]
Ls=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.vstack([Sd,Sd[:1]]),axis=0),axis=1))]
Lb=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.vstack([B,B[:1]]),axis=0),axis=1))]
k0=int(np.argmin(np.linalg.norm(Sd-B[0],axis=1)))
Sd=np.roll(Sd,-k0,axis=0); dense=np.roll(dense,-k0)
Ls=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.vstack([Sd,Sd[:1]]),axis=0),axis=1))]
fr=Lb[:-1]/Lb[-1]; th_i=[]
for f in fr:
    sv=f*Ls[-1]; k=int(np.clip(np.searchsorted(Ls,sv),1,len(Ls)-1)); al=(sv-Ls[k-1])/max(Ls[k]-Ls[k-1],1e-9)
    t0=dense[k-1]; t1=dense[k%len(dense)]; dt=np.angle(np.exp(1j*(t1-t0))); th_i.append(t0+al*dt)
rings={k:[] for k in ('S','b2','b1','rim','d3','d2','d1','floor')}
def at(C,L,sv):
    k=int(np.clip(np.searchsorted(L,sv),1,len(L)-1)); al=(sv-L[k-1])/max(L[k]-L[k-1],1e-9); return C[k-1]+(C[k]-C[k-1])*al
for t in th_i:
    C,Nn,L,ir,iS=info(t); sr=L[ir]; se=L[iS]
    rings['S'].append(C[iS]); rings['b2'].append(at(C,L,sr+2*(se-sr)/3)); rings['b1'].append(at(C,L,sr+(se-sr)/3)); rings['rim'].append(C[ir])
    rings['d3'].append(at(C,L,0.75*sr)); rings['d2'].append(at(C,L,0.5*sr)); rings['d1'].append(at(C,L,0.25*sr)); rings['floor'].append(at(C,L,0.06*sr))
order=['S','b2','b1','rim','d3','d2','d1','floor']
col0=int(np.bincount([cc[i] for i in loop]).argmax())
F=[f for k,f in enumerate(F) if k not in hole]; prev=loop; ids={}
N=NB
for nm in order:
    cur=[]
    for p in rings[nm]: V.append(np.asarray(p).tolist()); cc.append(col0); cur.append(len(V)-1)
    for i in range(N): F.append([prev[i],prev[(i+1)%N],cur[(i+1)%N],cur[i]])
    prev=cur; ids[nm]=cur
p=prev; a_,b_=0,N-1
while b_-a_>=3: F.append([p[a_],p[a_+1],p[b_-1],p[b_]]); a_+=1; b_-=1
if b_-a_==2: F.append([p[a_],p[a_+1],p[a_+2]])
Fa=np.full((len(F),4),-1)
for k,f in enumerate(F): Fa[k,:len(f)]=f
np.savez_compressed(out,V=np.array(V),F=Fa); np.save(out.replace('.npz','_col.npy'),np.array(cc))
json.dump(dict(side=s,hole=sorted(hole),loop=loop,rings=ids,floor=floor.tolist(),axis=A.tolist(),RS=RS),open(out.replace('.npz','_ear%s.json'%s),'w'))
print(s,'N',N,'new verts',len(V)-len(z['V']),'faces',len(F))
