import json, sys
B = json.load(open(sys.argv[1])); k = int(sys.argv[2])
acts = []
for v in B[k]:
    for a in v['acts']:
        a = dict(a)
        if a['action'] == 'key' or a['action'] == 'wait': a.pop('action_summary', None)
        acts.append(a)
acts += [{'action': 'wait', 'duration': 0.4}, {'action': 'zoom', 'region': [1040, 56, 1180, 120], 'scale': 0.6}]
print(json.dumps(acts, separators=(',', ':')))
