import json, sys
o = json.load(open(sys.argv[1])); view = sys.argv[2]; a0, a1 = int(sys.argv[3]), int(sys.argv[4])
acts = []
for v in o[view][a0:a1]:
    for a in v['acts']:
        a = dict(a)
        if a['action'] in ('key', 'wait'): a.pop('action_summary', None)
        acts.append(a)
acts += [{'action': 'wait', 'duration': 0.4}, {'action': 'zoom', 'region': [1040, 56, 1180, 120], 'scale': 0.6}]
print(json.dumps(acts, separators=(',', ':')))
