# crotch1.py CAGE COL OUT : crotch/pouch patch (4 columns x 6 rows) replacing faces 975-978,983-986,565,576,697,1219
import numpy as np, sys, json, os
from earsl import slice_loops
from holeloop import hole_loops
cg,colf,out=sys.argv[1:4]
z=np.load(cg); V=z['V'].astype(float).tolist(); F=[list(map(int,f[f>=0])) for f in z['F']]; cc=np.load(colf).tolist()
hole=[975,976,977,978,983,984,985,986,565,576,697,1219]
R=[20,19,18,17,16]; L=[8,9,10,11,12]
rung0=[638,637,625,613,614]; rung6=[756,1267,1259,1264,496]
ZMIN=float(os.environ.get('ZMIN','-0.3')); TIPF=float(os.environ.get('TIPF','1.0'))
RMAX=[float(t) for t in os.environ.get('RMAX','4.5,8,8,8,8').split(',')]
def sect(y,rmax=8):
    pts=[]
    for P,c in slice_loops(1,y):
        m=(P[:,0]>-9)&(P[:,0]<11)&(P[:,2]>97)&(P[:,2]<107); pts.append(P[m])
    P=np.vstack(pts)
    cm=(abs(P[:,0]-1.3)<1.2)&(P[:,2]<103.5); C=P[cm][np.argmax(P[cm][:,2])]
    out=[]
    for sg in (-1,1):
        m=(sg*(P[:,0]-C[0])>0.6)&(P[:,2]>=C[2]+ZMIN)&(np.linalg.norm(P[:,[0,2]]-C[[0,2]],axis=1)<rmax)
        Q=P[m]
        if len(Q)==0: Q=P[(sg*(P[:,0]-C[0])>0)&(P[:,2]>=C[2]-2)]
        T=Q[np.argmax(np.linalg.norm(Q[:,[0,2]]-C[[0,2]],axis=1))]
        out.append(C+TIPF*(T-C))
    return out[0],C,out[1]
rungs=[]
for k in range(5):
    y=(V[R[k]][1]+V[L[k]][1])/2; tR,C,tL=sect(y,RMAX[k])
    if k==0 and os.environ.get('R1','1')=='1': tR,C,tL=np.array([-2.46,-56.2,104.34]),np.array([0.83,-56.2,102.19]),np.array([4.24,-56.2,103.15])
    rungs.append([tR,C,tL]); print('rung',k+1,'y %.1f'%y,np.round(tR,1),np.round(C,1),np.round(tL,1))
F=[f for i,f in enumerate(F) if i not in set(hole)]
grid=[rung0]
for k in range(5):
    ids=[R[k]]
    for p,colr in zip(rungs[k],(1,1,1)):
        V.append(np.asarray(p).tolist()); cc.append(colr); ids.append(len(V)-1)
    ids.append(L[k]); grid.append(ids)
grid.append(rung6)
# orientation: original face 976 [626,471,10,9]: edge 626->471 runs front->back on L side... decide by checking directed edges after build
def build(flip):
    Fn=[]
    for k in range(6):
        a,b=grid[k],grid[k+1]
        for c in range(4):
            q=[a[c],a[c+1],b[c+1],b[c]]
            Fn.append(q[::-1] if flip else q)
    return Fn
import collections
for flip in (False,True):
    F2=F+build(flip)
    de=collections.Counter((f[i],f[(i+1)%len(f)]) for f in F2 for i in range(len(f)))
    if all(n==1 for n in de.values()) and all((b,a) in de for (a,b) in de): break
else: raise SystemExit('orientation failed')
used=sorted(set(i for f in F2 for i in f)); remap={o:n for n,o in enumerate(used)}
V2=np.array([V[i] for i in used]); F3=[[remap[i] for i in f] for f in F2]; cc2=np.array([cc[i] for i in used])
Fa=np.full((len(F3),4),-1)
for k,f in enumerate(F3): Fa[k,:len(f)]=f
np.savez_compressed(out,V=V2,F=Fa); np.save(out.replace('.npz','_col.npy'),cc2)
json.dump(dict(hole=hole,grid=[[remap[i] for i in r] for r in grid],removed=[i for i in range(len(z['V'])) if i not in remap]),open(out.replace('.npz','_crotch.json'),'w'))
print('V',len(V2),'F',len(F3),'flip',flip)
