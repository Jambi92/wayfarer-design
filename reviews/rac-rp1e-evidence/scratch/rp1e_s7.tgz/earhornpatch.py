# earhornpatch.py SIDE CAGE_IN(final chain cage) OUT HORNX [HZ HY] : move the ear T-ring horn verts in a later cage of the chain (found by position)
import numpy as np, sys, json
from scipy.spatial import cKDTree
from earsl import slice_loops
side,cin,out,hx=sys.argv[1:5]; hx=float(hx); HZ=float(sys.argv[5]) if len(sys.argv)>5 else 201.5; HY=float(sys.argv[6]) if len(sys.argv)>6 else -50.0
E=json.load(open('cage_EL_earL.json' if side=='L' else 'cage_ELR_earR.json')); base=np.load('cage_EL.npz' if side=='L' else 'cage_ELR.npz')['V']
T=[base[i] for i in E['rings'][0]]; R0=[base[i] for i in E['rings'][1]]
z=np.load(cin); V=z['V'].copy(); kd=cKDTree(V)
X=hx if side=='L' else 4-hx
P=np.vstack([P for P,c in slice_loops(0,X)]); P=P[(P[:,2]>196)&(P[:,1]<-40)&(P[:,1]>-60)]
mouth=set(E['mouth']); n=0
for i,(t,r) in enumerate(zip(T,R0)):
    if E['rings'][0][i] in mouth: continue
    if r[2]>HZ and r[1]<HY:
        d,j=kd.query(t); assert d<1e-6
        q=r.copy(); q[0]=X; V[j]=P[np.argmin(np.linalg.norm(P-q,axis=1))]; n+=1
np.savez_compressed(out,V=V,F=z['F']); print('moved',n)
