"""Radial chains about the concha axis (L/R ear). Saves earchains_S.npz: for each theta, chain points, normals, arc length, rim idx."""
import numpy as np, sys, collections, heapq, json
s=sys.argv[1]; N=int(sys.argv[2]) if len(sys.argv)>2 else 16
w=np.load('/home/claude/stc/rp1/weld.npz'); S=w['V'].astype(float); SF=w['F'].astype(np.int64)
e=np.load('ear_%s.npy'%s); d=np.load('sim_b4_L3_dsp.npy'); P=S[e]; floor=P[d[e]>=np.percentile(d[e],95)].mean(0)
mouth=S[np.load('earroot_%s.npy'%s)].mean(0); A=mouth-floor; A/=np.linalg.norm(A)
u=np.cross(A,[0,0,1.0]); u/=np.linalg.norm(u); v=np.cross(A,u)
box=(abs(S-floor)<[12,14,12]).all(1); Fb=SF[box[SF].all(1)]
fn=np.cross(S[SF[:,1]]-S[SF[:,0]],S[SF[:,2]]-S[SF[:,0]]); fn/=np.linalg.norm(fn,axis=1,keepdims=True)+1e-12
vn=np.zeros_like(S)
for k in range(3): np.add.at(vn,SF[:,k],fn)
vn/=np.linalg.norm(vn,axis=1,keepdims=True)+1e-12
def chain(t):
    e1=np.cos(t)*u+np.sin(t)*v; n=np.cross(A,e1); dd=(S-floor)@n; sgn=np.sign(dd[Fb]); T=Fb[(sgn.min(1)<0)&(sgn.max(1)>0)]
    key=lambda p:tuple(np.round(p,4)); adj=collections.defaultdict(list); pos={}; nor={}
    for tri in T:
        q=[];nq=[]
        for i,j in ((0,1),(1,2),(2,0)):
            if dd[tri[i]]*dd[tri[j]]<0:
                al=dd[tri[i]]/(dd[tri[i]]-dd[tri[j]]); q.append(S[tri[i]]+(S[tri[j]]-S[tri[i]])*al); nq.append(vn[tri[i]]*(1-al)+vn[tri[j]]*al)
        if len(q)==2 and (((np.array(q)-floor)@e1)>-0.3).all():
            a,b=key(q[0]),key(q[1]); adj[a].append(b); adj[b].append(a); pos[a]=q[0]; pos[b]=q[1]; nor[a]=nq[0]; nor[b]=nq[1]
    ks=list(pos); Pk=np.array([pos[k] for k in ks]); start=ks[int(np.argmin(np.linalg.norm(Pk-floor,axis=1)))]
    dist={start:0.0}; prev={start:None}; pq=[(0.0,start)]
    while pq:
        dc,k0=heapq.heappop(pq)
        if dc>dist[k0]: continue
        for k1 in adj[k0]:
            nd=dc+np.linalg.norm(pos[k1]-pos[k0])
            if nd<dist.get(k1,1e9): dist[k1]=nd; prev[k1]=k0; heapq.heappush(pq,(nd,k1))
    end=max(dist,key=dist.get); path=[end]
    while prev[path[-1]] is not None: path.append(prev[path[-1]])
    path=path[::-1]; C=np.array([pos[k] for k in path]); Nn=np.array([nor[k] for k in path])
    return C,Nn,e1
out={}
ths=np.linspace(0,2*np.pi,N,endpoint=False)
for i,t in enumerate(ths):
    C,Nn,e1=chain(t); L=np.r_[0,np.cumsum(np.linalg.norm(np.diff(C,axis=0),axis=1))]
    out['C%d'%i]=C; out['N%d'%i]=Nn; out['L%d'%i]=L
np.savez('earchains_%s.npz'%s,floor=floor,A=A,u=u,v=v,ths=ths,**out)
print(s,'floor',floor.round(1),'A',A.round(2))
