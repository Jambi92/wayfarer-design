import numpy as np, json, sys, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
cg=sys.argv[1]; js=sys.argv[2]; outp=sys.argv[3]
w=np.load('/home/claude/stc/rp1/weld.npz'); S=w['V']
z=np.load(cg); V=z['V']; F=[f[f>=0] for f in z['F']]; J=json.load(open(js)); fl=np.array(J['floor'])
box=(abs(S-fl)<[14,16,14]).all(1); P=S[box]
fig,ax=plt.subplots(1,3,figsize=(21,7))
for a,(i,j,nm) in zip(ax,[(0,2,'front x-z'),(1,2,'side y-z'),(0,1,'top x-y')]):
    a.scatter(P[:,i],P[:,j],s=0.2,c='0.7')
    for f in F:
        c=V[f].mean(0)
        if (abs(c-fl)<[14,16,14]).all():
            q=V[np.r_[f,f[0]]]; a.plot(q[:,i],q[:,j],'b-',lw=0.4)
    for k,cl in [('S','r'),('rim','m'),('d2','g'),('floor','k')]:
        q=V[J['rings'][k]+J['rings'][k][:1]]; a.plot(q[:,i],q[:,j],cl+'-',lw=1.2)
    q=V[J['loop']+J['loop'][:1]]; a.plot(q[:,i],q[:,j],'c-',lw=1.5)
    a.set_aspect('equal'); a.set_title(nm)
plt.tight_layout(); plt.savefig(outp,dpi=70)
