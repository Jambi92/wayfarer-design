import numpy as np, json, sys
from earsl import slice_loops
cg=sys.argv[1]; ring=sys.argv[2]; out=sys.argv[3]; XW=float(sys.argv[4]); YF=float(sys.argv[5]); FR=float(sys.argv[6]) if len(sys.argv)>6 else 1.0
z=np.load(cg);V=z['V'];R=json.load(open(ring))['rungs']; J={}
for a,b in R[:-1]:
    pa,pb=V[a],V[b]; x=(pa[0]+pb[0])/2
    if abs(x-2)>XW or min(pa[1],pb[1])>YF: continue
    best=None
    for P,c in slice_loops(0,x):
        ia=np.argmin(np.linalg.norm(P[:,1:]-pa[1:],axis=1)); ib=np.argmin(np.linalg.norm(P[:,1:]-pb[1:],axis=1))
        if np.linalg.norm(P[ia,1:]-pa[1:])>8 or np.linalg.norm(P[ib,1:]-pb[1:])>8: continue
        lo,hi=sorted((ia,ib)); seg1=P[lo:hi+1]; seg2=np.vstack([P[hi:],P[:lo+1]])
        seg=seg1 if len(seg1)<=len(seg2) else seg2
        ch=pb[1:]-pa[1:]; n=np.array([-ch[1],ch[0]])/np.linalg.norm(ch)
        dd=(seg[:,1:]-pa[1:])@n
        # inner side = towards +y (back); choose sign so that n points to +y
        if n[0]<0: dd=-dd
        i=np.argmax(dd); best=(dd[i],seg[i])
    if best:
        mid=(pa+pb)/2; J['%d,%d'%(a,b)]=(mid+FR*(best[1]-mid)).tolist(); print(a,b,round(x,1),'depth %.1f'%best[0],best[1].round(1))
json.dump(J,open(out,'w'))
