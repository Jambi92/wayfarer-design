import sys,numpy as np,json
from pathlib import Path
P=Path.cwd();sys.path.insert(0,str(P/'work/meshdeps'))
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra,connected_components
R=P/'work/hand_audit';z=np.load(R/'repaired.npz');V=z['V'];Q=z['Q'];frames=json.loads((P/'work/hand_frames.json').read_text());centers=np.array([frames[k]['C'] for k in frames])/100
mask=(np.min(np.linalg.norm(V[:,None,:]-centers,axis=2),axis=1)<.105)&(V[:,2]<1.14)&(abs(V[:,0])>.21)
E=np.concatenate([Q[:,[j,(j+1)%4]] for j in range(4)]);ee=E[mask[E].all(1)];g=coo_matrix((np.ones(len(ee)*2),(np.r_[ee[:,0],ee[:,1]],np.r_[ee[:,1],ee[:,0]])),shape=(len(V),len(V))).tocsr();_,lab=connected_components(g,directed=False);seed=[np.argmin(np.linalg.norm(V-c,axis=1)) for c in centers];mask&=np.isin(lab,np.unique(lab[seed]));np.save(R/'rig_hand_mask.npy',mask)
ids=np.where(mask)[0];mp=np.full(len(V),-1,dtype=int);mp[ids]=np.arange(len(ids));E=np.unique(np.sort(E[mask[E].all(1)],axis=1),axis=0);length=np.linalg.norm(V[E[:,0]]-V[E[:,1]],axis=1)
graph=coo_matrix((np.r_[length,length],(mp[np.r_[E[:,0],E[:,1]]],mp[np.r_[E[:,1],E[:,0]]])),shape=(len(ids),len(ids))).tocsr();bones=json.loads((R/'test_bones.json').read_text());frames=json.loads((P/'work/hand_frames.json').read_text());keys=list(frames);centers=np.array([frames[k]['C'] for k in keys])/100;owner=np.argmin(((V[ids,None,:]-centers)**2).sum(2),axis=1);Ds=[];names=[]
for b in bones:
 a=np.array(b['head']);c=np.array(b['tail']);side=a[0]>0;eligible=V[ids,0]>0 if side else V[ids,0]<0
 if '_bone_' in b['name']:
  key=b['name'].split('_bone_')[0];j=int(b['name'].split('_bone_')[1])
  if j>0:eligible&=owner==keys.index(key)
 cand=np.where(eligible)[0];seeds=[]
 for t in np.linspace(.05,.95,7):
  pt=a*(1-t)+c*t;seeds.append(int(cand[np.argmin(np.linalg.norm(V[ids[cand]]-pt,axis=1))]))
 dist=dijkstra(graph,directed=False,indices=np.unique(seeds),min_only=True);Ds.append(dist);names.append(b['name']);print('WEIGHT',b['name'],flush=True)
D=np.stack(Ds,axis=1);keydist=np.stack([D[:,[j for j,n in enumerate(names) if n.startswith(k+'_bone_')]].min(1) for k in keys],axis=1);keyowner=keydist.argmin(1);D-=D.min(1)[:,None];W=np.exp(-D/.006);W/=W.sum(1)[:,None]
for ki,key in enumerate(keys):
 group=sorted([n for n in names if n.startswith(key+'_bone_')])[-1];j=names.index(group);b=next(b for b in bones if b['name']==group);a=np.array(b['head']);e=np.array(b['tail'])-a;e/=np.linalg.norm(e);s=(V[ids]-a)@e;blend=np.clip(s/.012,0,1);blend=blend*blend*(3-2*blend);blend[(keyowner!=ki)|(np.linalg.norm(V[ids]-centers[ki],axis=1)>.045)]=0;W*=1-blend[:,None];W[:,j]+=blend
W[W<1e-5]=0;W/=W.sum(1)[:,None];np.savez_compressed(R/'geodesic_weights.npz',ids=ids,W=W,names=np.array(names));print('WEIGHTS COMPLETE',len(ids),len(names),flush=True)
