import sys,numpy as np,json
from pathlib import Path
P=Path.cwd();sys.path.insert(0,str(P/'work/meshdeps'));import pymeshlab
R=P/'work/hand_audit';out={};mask=np.load(R/'topological_hand_mask.npy')
for tag in ['actual_baseline','actual_refined','actual_repaired']:
 if len(sys.argv)>1 and tag!='actual_repaired':continue
 z=np.load(R/(tag+'.npz'));v=z['V'];f=z['F'];ms=pymeshlab.MeshSet();ms.add_mesh(pymeshlab.Mesh(v,f));ms.compute_selection_by_self_intersections_per_face();flag=ms.current_mesh().face_selection_array();np.save(R/(tag+'_flags.npy'),np.where(flag)[0]);out[tag]=dict(self_intersection_faces=int(flag.sum()),hand_self_intersection_faces=int((flag&mask[f].all(1)).sum()));print(tag,out[tag],flush=True);(P/'outputs/hand_actual_triangulation_audit.json').write_text(json.dumps(out,indent=2))
