import sys,numpy as np,json
from pathlib import Path
P=Path.cwd();sys.path.insert(0,str(P/'work/meshdeps'))
from scipy.sparse import coo_matrix,diags
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import spsolve
R=P/'work/hand_audit';z=np.load(R/'repaired.npz');V=z['V'].copy();Q=z['Q'];F=z['F'];B=np.load(R/'baseline.npz')['V'];frames=json.loads((P/'work/hand_frames.json').read_text());dims=json.loads((P/'outputs/fullscale_candidate_checks.json').read_text());hist=[];start=V.copy()
for key,fr in frames.items():
 if len(sys.argv)>1 and key!=sys.argv[1]:continue
 C=np.array(fr['C'])/100;e=np.array(dims[key]['axis']);near=np.linalg.norm(B-C,axis=1)<.025
 # Use the connected source terminal cap, preserving its exact outer boundary and topology.
 s=(B-C)@e;plane=float(sys.argv[2]) if len(sys.argv)>2 else -.020;eligible=(s>plane)&(np.linalg.norm(B-C,axis=1)<.05);qids=np.where(eligible[Q].all(1))[0];qq=Q[qids];edges=np.concatenate([qq[:,[j,(j+1)%4]] for j in range(4)]);ids=np.unique(qq);mp=np.full(len(V),-1,dtype=int);mp[ids]=np.arange(len(ids));es=mp[edges];g=coo_matrix((np.ones(len(es)*2),(np.r_[es[:,0],es[:,1]],np.r_[es[:,1],es[:,0]])),shape=(len(ids),len(ids))).tocsr();_,lab=connected_components(g,directed=False);seed=np.argmin(np.linalg.norm(B[ids]-C,axis=1));chosen=lab[mp[qq[:,0]]]==lab[seed];qids=qids[chosen];qq=Q[qids];edges=np.concatenate([qq[:,[j,(j+1)%4]] for j in range(4)]);ue,cnt=np.unique(np.sort(edges,axis=1),axis=0,return_counts=True);boundary=ue[cnt==1];adj={}
 for a,b in boundary:adj.setdefault(int(a),[]).append(int(b));adj.setdefault(int(b),[]).append(int(a))
 if not adj or any(len(x)!=2 for x in adj.values()):hist.append(dict(digit=key,status='SKIPPED non-simple boundary'));continue
 first=next(iter(adj));loop=[first];prev=-1;current=first
 while True:
  nxt=[x for x in adj[current] if x!=prev][0]
  if nxt==first:break
  if nxt in loop:break
  loop.append(nxt);prev,current=current,nxt
 if len(loop)!=len(adj):hist.append(dict(digit=key,status='SKIPPED multiple boundary loops'));continue
 loop=np.array(loop);ids=np.unique(qq);mp=np.full(len(V),-1,dtype=int);mp[ids]=np.arange(len(ids));lf=mp[np.concatenate([qq[:,[0,1,2]],qq[:,[0,2,3]]])];ee=np.unique(np.sort(np.concatenate([lf[:,[0,1]],lf[:,[1,2]],lf[:,[2,0]]]),axis=1),axis=0);dst=np.r_[ee[:,0],ee[:,1]];src=np.r_[ee[:,1],ee[:,0]];A=coo_matrix((np.ones(len(dst)),(dst,src)),shape=(len(ids),len(ids))).tocsr();deg=np.asarray(A.sum(1)).ravel();L=diags(deg)-A;b=mp[loop];interior=np.setdiff1d(np.arange(len(ids)),b)
 bp=V[loop];arclength=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.vstack([bp,bp[0]]),axis=0),axis=1))];angles=arclength[:-1]/arclength[-1]*2*np.pi;uv=np.zeros((len(ids),2));uv[b]=np.stack([np.cos(angles),np.sin(angles)],axis=1);uv[interior]=spsolve(L[interior][:,interior],-L[interior][:,b]@uv[b])
 rad=np.linalg.norm(uv,axis=1);theta=np.mod(np.arctan2(uv[:,1],uv[:,0]),2*np.pi);bv=np.stack([np.interp(theta,np.r_[angles,2*np.pi],np.r_[bp[:,j],bp[0,j]]) for j in range(3)],axis=1)
 center=bp.mean(0);oldcap=V[ids];apex=oldcap[np.argmax((oldcap-center)@e)];height=(apex-center)@e;rad=np.clip(rad,0,1);mapped=apex[None,:]*(1-rad[:,None])+bv*rad[:,None]+e[None,:]*height*(np.sqrt(np.maximum(1-rad**2,0))-(1-rad))[:,None];mapped[b]=bp
 V[ids]=mapped;tri=uv[lf];signed=(tri[:,1,0]-tri[:,0,0])*(tri[:,2,1]-tri[:,0,1])-(tri[:,1,1]-tri[:,0,1])*(tri[:,2,0]-tri[:,0,0]);hist.append(dict(digit=key,status='REBUILT',vertices=len(ids),boundary_vertices=len(b),uv_opposite_orientation_triangles=int(min((signed>0).sum(),(signed<0).sum())),max_move_mm=float(np.linalg.norm(mapped-oldcap,axis=1).max()*1000)));print(hist[-1],flush=True)
np.savez_compressed(R/'repaired.npz',V=V,Q=Q,F=F);(P/('outputs/distal_cap_rebuild_'+sys.argv[1]+'.json' if len(sys.argv)>1 else 'outputs/distal_cap_rebuild.json')).write_text(json.dumps(hist,indent=2))
