import bpy,numpy as np,json,math,sys
from pathlib import Path
from mathutils import Vector,Quaternion
P=Path.cwd();O=P/'outputs';W=P/'work/hand_audit';bpy.ops.wm.open_mainfile(filepath=str(O/'Gorrund_claw_integration_refined_review.blend'));sc=bpy.context.scene
body=bpy.data.objects['Gorrund_claw_integration_refined_review'];z=np.load(W/'repaired.npz');V=z['V'];Q=z['Q'];body.data.vertices.foreach_set('co',V.ravel());body.data.update();body.name='Gorrund_hand_quality_candidate'
for o in list(bpy.data.objects):
 if 'flexion' in o.name.lower():bpy.data.objects.remove(o,do_unlink=True)
baseline=bpy.data.objects['Baseline_v015_UNCHANGED'];B=np.array([v.co[:] for v in baseline.data.vertices]);N=np.array([v.normal[:] for v in baseline.data.vertices]);baseline.hide_render=True;baseline.hide_set(True)
frames=json.loads((P/'work/hand_frames.json').read_text());dims=json.loads((O/'fullscale_candidate_checks.json').read_text());handmask=np.load(W/('rig_hand_mask.npy' if (W/'rig_hand_mask.npy').exists() else 'topological_hand_mask.npy'));land={};claws=[]
for key,fr in frames.items():
 e=np.array(dims[key]['axis']);C=np.array(fr['C'])/100;near=np.linalg.norm(B-C,axis=1)<.003;n=N[near].mean(0);n-=n@e*e;n/=np.linalg.norm(n);u=np.cross(n,e);claw=bpy.data.objects[key+'_claw'];root=np.array([v.co[:] for v in claw.data.vertices[:48]]).mean(0);claws.append(claw)
 tip=root+e*.006-n*.009;dip=tip-e*(.022 if 'thumb' not in key else .018)
 pip=dip+np.array([0,0,.032]);mcp=pip+np.array([0,0,.033])
 # Fit proximal joint centres to the actual mesh cross-sections, not a generic vertical chain.
 sidekeys=[k for k in frames if ('_L' in k)==('_L' in key) and 'thumb' not in k];ys=sorted([frames[k]['C'][1]/100 for k in sidekeys]);cy=C[1];j=ys.index(cy) if cy in ys else 0
 low=(ys[j-1]+cy)*.5 if j>0 else cy-.025;high=(ys[j+1]+cy)*.5 if j<len(ys)-1 else cy+.025
 def section(zheight,fallback):
  select=handmask&(abs(B[:,2]-zheight)<.0012)&(B[:,1]>low)&(B[:,1]<high)&(B[:,0]*np.sign(C[0])>.22)&(np.linalg.norm(B-C,axis=1)<.18)
  vv=B[select]
  if len(vv)<10:return fallback
  return np.array([.5*(vv[:,0].min()+vv[:,0].max()),.5*(vv[:,1].min()+vv[:,1].max()),zheight])
 if 'thumb' not in key:
  dz=min(C[2]+.035,1.025);dip=section(dz,dip);pip=section((dz+1.055)*.5,pip);mcp=section(1.055,mcp)
 if 'thumb' in key:mcp=dip+np.array([0,0,.035]);points=[mcp,dip,tip]
 else:points=[mcp,pip,dip,tip]
 land[key]=dict(C=C,e=e,n=n,u=u,points=points,claw=claw)
arm=bpy.data.armatures.new('Gorrund_HAND_TEST_RIG');rig=bpy.data.objects.new('Gorrund_HAND_TEST_RIG',arm);sc.collection.objects.link(rig);rig.show_in_front=True
bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT');segments={};bonekeys={}
for side in ['L','R']:
 ks=[k for k in land if '_'+side in k];wrist=np.array([np.mean([land[k]['points'][0][0] for k in ks]),np.mean([land[k]['C'][1] for k in ks]),max(land[k]['points'][0][2] for k in ks)+.025]);rootbone=arm.edit_bones.new(side+'_hand_root');rootbone.head=wrist;rootbone.tail=wrist+[0,0,.025]
 for key in ks:
  pts=[wrist]+land[key]['points'];parent=rootbone;names=[]
  for j in range(len(pts)-1):
   name=key+f'_bone_{j}';bone=arm.edit_bones.new(name);bone.head=pts[j];bone.tail=pts[j+1];bone.parent=parent;bone.use_connect=False;parent=bone;segments[name]=(np.array(pts[j]),np.array(pts[j+1]),key,j);names.append(name)
  bonekeys[key]=names
bpy.ops.object.mode_set(mode='OBJECT')
if '--layout' in sys.argv:
 (W/'test_bones.json').write_text(json.dumps([dict(name=b.name,head=list(b.head_local),tail=list(b.tail_local)) for b in arm.bones],indent=2));sys.exit(0)
# Distance-based blended weights on the connected hand regions only.
ids=np.where(handmask)[0];points=V[ids];names=list(segments);D=[]
for name in names:
 a,b,key,j=segments[name];ab=b-a;t=np.clip((points-a)@ab/(ab@ab),0,1);dist=np.linalg.norm(points-(a+t[:,None]*ab),axis=1)
 D.append(dist)
D=np.stack(D,axis=1);weights=np.exp(-.5*(D/.010)**2);weights[D>.035]=0
# Palm stays with the root unless close enough to a phalanx.
maxweight=weights.max(1);sums=weights.sum(1);weights/=np.maximum(sums,1e-12)[:,None];strength=np.clip(maxweight/.05,0,1);weights*=strength[:,None]
geo=None
if (W/'geodesic_weights.npz').exists():
 geo=np.load(W/'geodesic_weights.npz');assert np.array_equal(geo['ids'],ids);gnames=list(geo['names']);names=gnames;weights=geo['W'];strength=np.ones(len(ids))
for j,name in enumerate(names):
 vg=body.vertex_groups.new(name=name)
 for i in np.where(weights[:,j]>0)[0]:vg.add([int(ids[i])],float(weights[i,j]),'REPLACE')
for side in ([] if geo is not None else ['L','R']):
 vg=body.vertex_groups.new(name=side+'_hand_root');sel=(points[:,0]>0) if side=='L' else(points[:,0]<0);quant=np.rint((1-strength)*100).astype(int)
 for k in range(1,101):
  group=ids[(quant==k)&sel]
  if len(group):vg.add(group.tolist(),k/100,'REPLACE')
mod=body.modifiers.new('Hand armature test','ARMATURE');mod.object=rig;mod.use_deform_preserve_volume=True
for key,lm in land.items():
 ob=lm['claw'];group=ob.vertex_groups.new(name=bonekeys[key][-1]);group.add(list(range(len(ob.data.vertices))),1,'REPLACE');md=ob.modifiers.new('Follow distal bone','ARMATURE');md.object=rig
fixtures=[];targets=[];report={}
def aim(pb,axis,deg):
 local=pb.bone.matrix_local.to_3x3().inverted()@Vector(axis);pb.rotation_mode='QUATERNION';pb.rotation_quaternion=Quaternion(local,math.radians(deg))
def reset():
 for pb in rig.pose.bones:
  pb.rotation_mode='QUATERNION';pb.rotation_quaternion=(1,0,0,0)
  for c in list(pb.constraints):pb.constraints.remove(c)
 for o in fixtures+targets:bpy.data.objects.remove(o,do_unlink=True)
 fixtures.clear();targets.clear()
def ik(key,target):
 ob=bpy.data.objects.new(key+'_IK_target',None);sc.collection.objects.link(ob);ob.location=target;targets.append(ob);c=rig.pose.bones[bonekeys[key][-1]].constraints.new('IK');c.target=ob;c.chain_count=len(bonekeys[key]) if 'thumb' in key else len(bonekeys[key])-1;c.use_stretch=False;c.iterations=150
def fixture(loc,kind):
 bpy.ops.mesh.primitive_cylinder_add(vertices=48,radius=.016 if kind=='handle' else .011,depth=.15 if kind=='handle' else .002,location=loc);ob=bpy.context.object;ob.name='TEST_FIXTURE_'+kind
 if kind=='handle':ob.rotation_euler[0]=math.pi/2
 fixtures.append(ob)
sc.render.resolution_x=900;sc.render.resolution_y=900;cam=sc.camera;cam.data.type='ORTHO';F=z['F'];facekeep=handmask[F].all(1);hf=F[facekeep];used=np.unique(hf);mp=np.full(len(V),-1,dtype=int);mp[used]=np.arange(len(used))
for mode in ['relaxed','fist','precision_pinch','handle_grip']:
 reset()
 if mode=='fist':
  for key,lm in land.items():
   ns=bonekeys[key]
   for j,name in enumerate(ns[1:]):aim(rig.pose.bones[name],lm['u'],[20,40,25][min(j,2)] if 'thumb' not in key else [15,20][min(j,1)])
 elif mode=='precision_pinch':
  for side,idx in [('L','A_L20'),('R','A_R21')]:
   thumb='A_'+side+'thumb';a=land[idx]['points'][-1];b=land[thumb]['points'][-1];mid=(a+b)*.5;direction=b-a;direction/=np.linalg.norm(direction);ik(idx,mid-direction*.002);ik(thumb,mid+direction*.002);fixture(mid,'coin')
 elif mode=='handle_grip':
  for side in ['L','R']:
   keys=[k for k in land if '_'+side in k];center=np.mean([land[k]['points'][-1] for k in keys],axis=0);center[2]+=.027;center[0]+=.008 if side=='L' else-.008;fixture(center,'handle')
   for key in keys:
    tip=land[key]['points'][-1];rad=tip-center;rad[1]=0;rad/=np.linalg.norm(rad);goal=center+rad*.019;goal[1]=tip[1];ik(key,goal)
 bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();ev=body.evaluated_get(deps);me=ev.to_mesh();posed=np.empty(len(me.vertices)*3);me.vertices.foreach_get('co',posed);posed=posed.reshape(-1,3);ev.to_mesh_clear()
 np.savez_compressed(W/('rig_pose_'+mode+'.npz'),V=posed[used],F=mp[hf])
 ikerror={}
 for key in land:
  pb=rig.pose.bones[bonekeys[key][-1]]
  if pb.constraints:ikerror[key]=float((pb.tail-pb.constraints[0].target.location).length*1000)
 report[mode]=dict(finite_coordinates=bool(np.isfinite(posed).all()),vertices_moved_outside_hand_regions=int((np.linalg.norm(posed[~handmask]-V[~handmask],axis=1)>1e-7).sum()),ik_target_error_mm=ikerror)
 for side,t,d in [('left',(.305,-.50,.97),(.2,-.2,-1)),('right',(-.305,-.42,.96),(-.2,-.2,-1))]:
  target=Vector(t);cam.location=target+Vector(d).normalized()*4;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.34;sc.render.filepath=str(O/f'hand_rig_{side}_{mode}.png');bpy.ops.render.render(write_still=True)
 print('POSE',mode,json.dumps(report[mode]),flush=True)
reset();bpy.context.view_layer.update();rig['status']='Fitted hand TEST rig. Not production accepted.';sc['status']='Hand geometry repair and four-pose test candidate. Audit results must be read before use.'
bpy.ops.wm.save_as_mainfile(filepath=str(O/'Gorrund_hand_quality_test_rig.blend'),compress=True)
(O/'hand_rig_pose_checks.json').write_text(json.dumps(dict(bones=len(arm.bones),poses=report,status='Test rig only. Pose mesh intersection audit pending.'),indent=2))
